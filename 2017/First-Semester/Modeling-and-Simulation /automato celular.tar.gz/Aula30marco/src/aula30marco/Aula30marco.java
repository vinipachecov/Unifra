/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula30marco;

/**
 *
 * @author root
 */
public class Aula30marco {

    /**
     * @param args the command line arguments
     */
    
    //Qual é o estado
    //Qual é a coluna
    //Qual é a linha
    //Aplicar regras
    //Qual o método
    /*
    Função de evoluir
    */
    
    public static void main(String[] args) {
        //setup matrix of automaton
//        Matrix mat = new Matrix(4,4);
//        mat.patternMatrix(1);
//        System.out.println("GERACAO INICIAL -- XXXXXXXXXXXXXX");
//        mat.printStates();                
        
//        for (int i = 0; i < 2; i++) {
//            mat = mat.newGenaration();           
//        }
         
    }
    
}
