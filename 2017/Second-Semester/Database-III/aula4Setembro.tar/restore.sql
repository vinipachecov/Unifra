--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.itemcompra DROP CONSTRAINT itemcompra_codproduto_fkey;
ALTER TABLE ONLY public.itemcompra DROP CONSTRAINT itemcompra_codcompra_fkey;
ALTER TABLE ONLY public.compra DROP CONSTRAINT compra_id_pessoa_fkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_pkey;
ALTER TABLE ONLY public.produto DROP CONSTRAINT produto_nome_key;
ALTER TABLE ONLY public.itemcompra DROP CONSTRAINT itemcompra_pkey;
ALTER TABLE ONLY public.compra DROP CONSTRAINT compra_pkey;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_pkey;
ALTER TABLE ONLY public.cliente DROP CONSTRAINT cliente_email_key;
ALTER TABLE public.produto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.compra ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cliente ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.produto_id_seq;
DROP TABLE public.produto;
DROP TABLE public.itemcompra;
DROP SEQUENCE public.compra_id_seq;
DROP TABLE public.compra;
DROP SEQUENCE public.cliente_id_seq;
DROP TABLE public.cliente;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE cliente (
    id integer NOT NULL,
    nome character varying(150) NOT NULL,
    email character varying(100) NOT NULL
);


ALTER TABLE cliente OWNER TO postgres;

--
-- Name: cliente_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE cliente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cliente_id_seq OWNER TO postgres;

--
-- Name: cliente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE cliente_id_seq OWNED BY cliente.id;


--
-- Name: compra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE compra (
    id integer NOT NULL,
    id_pessoa integer NOT NULL,
    total integer NOT NULL,
    datacompra timestamp without time zone
);


ALTER TABLE compra OWNER TO postgres;

--
-- Name: compra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE compra_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE compra_id_seq OWNER TO postgres;

--
-- Name: compra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE compra_id_seq OWNED BY compra.id;


--
-- Name: itemcompra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE itemcompra (
    codcompra integer NOT NULL,
    codproduto integer NOT NULL,
    total integer NOT NULL,
    quantidade integer NOT NULL
);


ALTER TABLE itemcompra OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE produto (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    valorunitario double precision
);


ALTER TABLE produto OWNER TO postgres;

--
-- Name: produto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE produto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE produto_id_seq OWNER TO postgres;

--
-- Name: produto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE produto_id_seq OWNED BY produto.id;


--
-- Name: cliente id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cliente ALTER COLUMN id SET DEFAULT nextval('cliente_id_seq'::regclass);


--
-- Name: compra id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY compra ALTER COLUMN id SET DEFAULT nextval('compra_id_seq'::regclass);


--
-- Name: produto id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY produto ALTER COLUMN id SET DEFAULT nextval('produto_id_seq'::regclass);


--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY cliente (id, nome, email) FROM stdin;
\.
COPY cliente (id, nome, email) FROM '$$PATH$$/2159.dat';

--
-- Name: cliente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('cliente_id_seq', 5, true);


--
-- Data for Name: compra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY compra (id, id_pessoa, total, datacompra) FROM stdin;
\.
COPY compra (id, id_pessoa, total, datacompra) FROM '$$PATH$$/2161.dat';

--
-- Name: compra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('compra_id_seq', 8, true);


--
-- Data for Name: itemcompra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY itemcompra (codcompra, codproduto, total, quantidade) FROM stdin;
\.
COPY itemcompra (codcompra, codproduto, total, quantidade) FROM '$$PATH$$/2164.dat';

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY produto (id, nome, valorunitario) FROM stdin;
\.
COPY produto (id, nome, valorunitario) FROM '$$PATH$$/2163.dat';

--
-- Name: produto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('produto_id_seq', 5, true);


--
-- Name: cliente cliente_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cliente
    ADD CONSTRAINT cliente_email_key UNIQUE (email);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (id);


--
-- Name: compra compra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY compra
    ADD CONSTRAINT compra_pkey PRIMARY KEY (id);


--
-- Name: itemcompra itemcompra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY itemcompra
    ADD CONSTRAINT itemcompra_pkey PRIMARY KEY (codcompra, codproduto);


--
-- Name: produto produto_nome_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY produto
    ADD CONSTRAINT produto_nome_key UNIQUE (nome);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (id);


--
-- Name: compra compra_id_pessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY compra
    ADD CONSTRAINT compra_id_pessoa_fkey FOREIGN KEY (id_pessoa) REFERENCES cliente(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: itemcompra itemcompra_codcompra_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY itemcompra
    ADD CONSTRAINT itemcompra_codcompra_fkey FOREIGN KEY (codcompra) REFERENCES compra(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: itemcompra itemcompra_codproduto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY itemcompra
    ADD CONSTRAINT itemcompra_codproduto_fkey FOREIGN KEY (codproduto) REFERENCES produto(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

