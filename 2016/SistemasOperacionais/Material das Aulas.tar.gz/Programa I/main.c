#include <stdio.h>
#include <string.h>

int main(int argc, const char**argv){

	printf("Ola mundo loco e o numero enviado eh %s \n", argv[1] );
	return 0;
}
